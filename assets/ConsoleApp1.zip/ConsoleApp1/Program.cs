﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	class Program {
		public static String chars = "rAoBRcDQhnFOdvTkCiSgwufMpWKxHatsyPLlYqzEjbGIeXJZmUNV";
		public static Char[] charsAr = chars.ToCharArray();

		public static int keyLen = 4;
		public static int keyPartLen = 4;
		public static int checkerPos = 1;

		static void Main(string[] args) {
			Console.WriteLine("Write 0 for Generation and 1 for Validation");
			String choice = Console.ReadLine();
			switch (choice) {
				case "0":
					Console.Clear();
					Console.WriteLine("Generated Key:");
					Console.WriteLine(generateKey());
					break;
				case "1":
					Console.WriteLine("Enter key to validate: ");
					string keyToVal = Console.ReadLine();
					Console.WriteLine(validateKey(keyToVal));
					break;
				default:
					Console.Clear();
					Console.WriteLine("Only choose value between 0-1");
					break;
			}
		}
		static String generateKey() {
			Random rand = new Random();
			int[][] keyParts = new int[keyLen][];
			for (int i = 0; i < keyLen; i++) {
				keyParts[i] = new int[keyPartLen];
				for (int n = 0; n < keyPartLen; n++) {
					keyParts[i][n] = rand.Next(0, 51);
				}
			}

			String key = arrayToKey(keyParts, true);
			String checkString = "";

			int checkVal = 0;
			for (int i = 0; i < keyParts.Length; i++){
				int checkPartVal = 1;
				for (int n = 0; n < keyParts[i].Length; n++) {
					if (n < keyPartLen - 1) {
						if (checkPartVal <= 9999) { checkPartVal *= keyParts[i][n] + 2; } else { checkPartVal /= keyParts[i][n] + 2; }
					} else {
						do
						{
							checkPartVal /= keyParts[i][n] + 1;
						} while (checkPartVal > 9999);
					}
				};
				checkVal += checkPartVal;
			}
			key = SingleIntToKey(checkVal) + "-" + key;
			return key;
		}

		static String arrayToKey(int[][] array, bool addDash)
		{
			String key = "";
			for (int i = 0; i < array.Length; i++) {
				for (int n = 0; n < array[i].Length; n++) {
					key += intToLetter(array[i][n]);
				};
				if (i < keyLen - 1 && addDash) {
					key += "-";
				}

			}
			return key;
		}

		static String SingleIntToKey(int Int) {
			String key = "";
			Char[] intAr = Int.ToString().ToCharArray();
			for (int i = 0; i < intAr.Length; i++) {
				String numberSt = intToLetter(int.Parse(intAr[i].ToString()));
				key += numberSt;
			}
			return key;
		}
		static String intToLetter(int Int) {
			if (Int > charsAr.Length) { Console.WriteLine("INT TO LETTER FAILED: INT TOO BIG"); }
			return charsAr[Int].ToString();
		}

		static String validateKey(String key)
		{
			return keyToInt(key);
		}

		static String keyToInt(String key) {
			String returnInt = "";
			char[] keyChars = key.ToCharArray();
			foreach (char Char in keyChars) {
				for (int i = 0; i < charsAr.Length; i++) {
					if (charsAr[i] == Char) {
						returnInt += i;
					};
				}
			}
			return returnInt;
		}
	}
}